#!/usr/bin/env python

from download import downloader
from transform import transformer
from json import dumps as stringify

class prep_scraper:
    def __init__(self, prep='http://cms.cern.ch/iCMS/prep/'):
        self.downloader = downloader(prep)
        self.request = None

    def get(self, pid=''):
        try:
           self.request = self.downloader.download(pid)
        except Exception as ex:
            print 'Error: Could not retrieve results. Reason: '+str(ex)
            return None
        return transformer.transform(self.request)

if __name__=='__main__':
    from sys import argv, exit
    prep = prep_scraper()
    if len(argv) < 2:
        print 'Give us a prep id'
        exit(1)
    try:
        print stringify(prep.get(argv[1]))
    except Exception, ex:
        print '####### REQUEST: %s EXCEPTION: %s' % (argv[1], ex)
